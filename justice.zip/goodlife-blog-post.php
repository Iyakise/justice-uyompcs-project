<?php
    define('__MPC_GENERAL_PERMIT__', '/asset/inc-files/');
    
   // require_once dirname(__FILE__) . "/functions/mpc-func.php";
  // echo constant(__MPC_GENERAL_PERMIT__);
    require_once dirname(__FILE__) .__MPC_GENERAL_PERMIT__. "head.php";
?>









<script>
  document.title = "Blog post";
</script>