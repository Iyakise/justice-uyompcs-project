<?php

header("Location:/diet/index.php");
?>